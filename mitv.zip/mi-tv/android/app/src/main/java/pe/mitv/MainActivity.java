package pe.mitv;

import android.app.Activity;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends Activity {
    private WebView web;

    /* Identidades que se prueban en orden si un servidor bloquea (401/403/406/429/451) */
    private static final String[] UAS = {
        "VLC/3.0.20 LibVLC/3.0.20",
        "Mozilla/5.0 (Linux; Android 11; BRAVIA 4K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36",
        "Lavf/60.3.100"
    };

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        web = new WebView(this);
        setContentView(web);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        s.setAllowUniversalAccessFromFileURLs(true);
        s.setAllowFileAccessFromFileURLs(true);
        web.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        web.setBackgroundColor(0xFF060A12);
        web.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                try { return proxy(r); } catch (Throwable t) { return null; }
            }
            /* Si el motor de la WebView se cierra por falta de memoria, la app se reinicia sola */
            @Override public boolean onRenderProcessGone(WebView v, RenderProcessGoneDetail d) {
                recreate();
                return true;
            }
        });
        web.setSystemUiVisibility(View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        web.loadUrl("file:///android_asset/index.html");
        web.requestFocus();
    }

    /* ===== Proxy nativo antibloqueo =====
       Todas las peticiones de listas y video salen desde aquí: sin Referer ni Origin (los servidores
       que bloquean por dominio dejan de rechazarlas), con identidad de reproductor y reintento con
       otra identidad si hay bloqueo, siguiendo redirecciones http↔https y con cabeceras CORS. */
    private WebResourceResponse proxy(WebResourceRequest r) throws Exception {
        Uri u = r.getUrl();
        String sch = u.getScheme(), host = u.getHost() == null ? "" : u.getHost();
        if (!"http".equals(sch) && !"https".equals(sch)) return null;
        if (host.endsWith("googleapis.com") || host.endsWith("gstatic.com")) return null;   // tipografías: que las maneje la WebView
        String method = r.getMethod();
        if ("OPTIONS".equalsIgnoreCase(method)) return resp(204, "No Content", "text/plain", new ByteArrayInputStream(new byte[0]), null);
        if (!"GET".equalsIgnoreCase(method) && !"HEAD".equalsIgnoreCase(method)) return null;
        String range = r.getRequestHeaders() == null ? null : r.getRequestHeaders().get("Range");

        HttpURLConnection c = null;
        String origen = u.toString(), cur = origen;
        for (int ua = 0; ua < UAS.length; ua++) {
            cur = origen;
            c = null;
            for (int hop = 0; hop < 8; hop++) {
                try {
                    c = (HttpURLConnection) new URL(cur).openConnection();
                    c.setInstanceFollowRedirects(false);
                    c.setConnectTimeout(8000);
                    c.setReadTimeout(15000);
                    c.setRequestMethod(method.toUpperCase());
                    c.setRequestProperty("User-Agent", UAS[ua]);
                    c.setRequestProperty("Accept", "*/*");
                    c.setRequestProperty("Connection", "keep-alive");
                    if (range != null) c.setRequestProperty("Range", range);
                    int code = c.getResponseCode();
                    if (code >= 300 && code < 400 && c.getHeaderField("Location") != null) {
                        cur = new URL(new URL(cur), c.getHeaderField("Location")).toString();
                        c.disconnect();
                        continue;
                    }
                    break;
                } catch (Exception e) {
                    if (c != null) c.disconnect();
                    c = null;
                    break;
                }
            }
            if (c == null) { if (ua == UAS.length - 1) break; else continue; }
            int code = c.getResponseCode();
            if ((code == 401 || code == 403 || code == 406 || code == 429 || code == 451) && ua < UAS.length - 1) { c.disconnect(); continue; }
            break;
        }
        if (c == null) return resp(502, "Bad Gateway", "text/plain", new ByteArrayInputStream(new byte[0]), null);

        int code = c.getResponseCode();
        String msg = c.getResponseMessage();
        InputStream in = code >= 400 ? c.getErrorStream() : c.getInputStream();
        if (in == null) in = new ByteArrayInputStream(new byte[0]);
        String ct = c.getContentType();
        String mime = ct == null ? "application/octet-stream" : ct.split(";")[0].trim();
        String path = Uri.parse(cur).getPath() == null ? "" : Uri.parse(cur).getPath().toLowerCase();
        boolean lista = path.endsWith(".m3u8") || path.endsWith(".m3u") || mime.contains("mpegurl");
        if (lista && (mime.equals("application/octet-stream") || mime.startsWith("text/"))) mime = "application/vnd.apple.mpegurl";
        else if (path.endsWith(".ts") && mime.equals("application/octet-stream")) mime = "video/mp2t";

        Map<String, String> extra = new HashMap<>();
        if (c.getHeaderField("Content-Range") != null) extra.put("Content-Range", c.getHeaderField("Content-Range"));
        if (c.getHeaderField("Accept-Ranges") != null) extra.put("Accept-Ranges", c.getHeaderField("Accept-Ranges"));

        /* Si hubo redirección a otro host, las rutas relativas de la lista se vuelven absolutas
           para que el reproductor siga encontrando los fragmentos */
        if (lista && !cur.equals(origen) && code < 400) {
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] buf = new byte[8192]; int k;
            while ((k = in.read(buf)) > 0) bo.write(buf, 0, k);
            in.close();
            String txt = reescribir(new String(bo.toByteArray(), StandardCharsets.UTF_8), cur);
            return resp(code, msg, mime, new ByteArrayInputStream(txt.getBytes(StandardCharsets.UTF_8)), extra);
        }
        return resp(code, msg, mime, in, extra);
    }

    private static final Pattern URI_ATTR = Pattern.compile("URI=\"([^\"]+)\"");

    private String reescribir(String txt, String base) {
        StringBuilder sb = new StringBuilder();
        for (String l : txt.split("\\r?\\n", -1)) {
            String t = l.trim();
            if (t.isEmpty()) { sb.append(l); }
            else if (t.startsWith("#")) {
                Matcher m = URI_ATTR.matcher(l);
                StringBuffer o = new StringBuffer();
                while (m.find()) m.appendReplacement(o, Matcher.quoteReplacement("URI=\"" + absoluta(base, m.group(1)) + "\""));
                m.appendTail(o);
                sb.append(o);
            } else sb.append(absoluta(base, t));
            sb.append('\n');
        }
        return sb.toString();
    }

    private String absoluta(String base, String rel) {
        try { return new URL(new URL(base), rel).toString(); } catch (Exception e) { return rel; }
    }

    private WebResourceResponse resp(int code, String msg, String mime, InputStream in, Map<String, String> extra) {
        if (code < 100 || code > 599 || (code >= 300 && code < 400)) code = 502;
        if (msg == null || msg.isEmpty()) msg = code < 400 ? "OK" : "Error";
        Map<String, String> h = new HashMap<>();
        h.put("Access-Control-Allow-Origin", "*");
        h.put("Access-Control-Allow-Headers", "*");
        h.put("Access-Control-Allow-Methods", "GET, HEAD, OPTIONS");
        h.put("Access-Control-Expose-Headers", "*");
        h.put("Cache-Control", "no-cache");
        if (extra != null) h.putAll(extra);
        return new WebResourceResponse(mime, "utf-8", code, msg, h, in);
    }

    /* ===== Control remoto: canal +/-, Menú/Info → calidad ===== */
    @Override public boolean dispatchKeyEvent(KeyEvent e) {
        if (e.getAction() == KeyEvent.ACTION_DOWN && e.getRepeatCount() == 0) {
            String js = null;
            switch (e.getKeyCode()) {
                case KeyEvent.KEYCODE_CHANNEL_UP: case KeyEvent.KEYCODE_PAGE_UP: js = "window.canalMenos&&canalMenos()"; break;
                case KeyEvent.KEYCODE_CHANNEL_DOWN: case KeyEvent.KEYCODE_PAGE_DOWN: js = "window.canalMas&&canalMas()"; break;
                case KeyEvent.KEYCODE_MENU: case KeyEvent.KEYCODE_INFO: case KeyEvent.KEYCODE_PROG_RED: js = "window.menuCalidad&&menuCalidad()"; break;
            }
            if (js != null) { web.evaluateJavascript(js, null); return true; }
        }
        return super.dispatchKeyEvent(e);
    }

    @Override public void onBackPressed() {
        web.evaluateJavascript("(window.atras&&window.atras())?'1':'0'", v -> {
            if (!"\"1\"".equals(v)) finish();
        });
    }

    @Override protected void onPause() { super.onPause(); web.onPause(); }
    @Override protected void onResume() {
        super.onResume();
        web.onResume();
        new Handler().postDelayed(() -> web.evaluateJavascript("window.alVolver&&alVolver()", null), 1500);   // reengancha el canal tras suspensión
    }
}
